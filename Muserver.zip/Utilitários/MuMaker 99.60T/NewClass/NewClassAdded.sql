USE [MuOnline]
INSERT INTO DefaultClassType (Class, Strength, Dexterity, Vitality, Energy, Life, MaxLife, Mana, MaxMana, MapNumber, MapPosX, MapPosY, DbVersion, Leadership, [Level], LevelUpPoint)
VALUES (80,21,21,18,23,70,70,40,40,0,182,128,3,0,1,0)
